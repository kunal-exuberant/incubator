package likedriving.design.QuizApp.models;

public class Score {



}

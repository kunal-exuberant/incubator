package likedriving.design.QuizApp.models;

public interface IQuestion {

}

package likedriving.design.QuizApp.models;

public enum QuestionType {
    SINGLE_CORRECT_ANSWER,
    MULTI_CORRECT_ANSWER,
    FREE_FORM
}
